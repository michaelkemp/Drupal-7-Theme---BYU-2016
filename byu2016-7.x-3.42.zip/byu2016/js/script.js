(function ($) { jQuery(document).ready(function($) {
    
    console.log("BYU 2016 Theme");
    
}); }(jQuery));      